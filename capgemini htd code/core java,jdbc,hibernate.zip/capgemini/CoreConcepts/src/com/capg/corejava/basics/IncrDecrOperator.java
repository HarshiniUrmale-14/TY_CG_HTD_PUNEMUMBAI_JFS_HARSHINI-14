package com.capg.corejava.basics;

public class IncrDecrOperator {

	public static void main(String[] args) {
	int i=10,j=20;
	i=++i;
	System.out.println(i);
	j=j++;
	System.out.println(j);
	int k=j++;
	System.out.println(k);
	System.out.println(j);
	
	i=--i;
	System.out.println(i);
	j=j--;
	System.out.println(j);
	
	}

}
