package com.capg.corejava.vikas;

public class Marker extends Pen {
	int size=5;
	void color() {
		System.out.println("marker is available in different color");
	}

}
