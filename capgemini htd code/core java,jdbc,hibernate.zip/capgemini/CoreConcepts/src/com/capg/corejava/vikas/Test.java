package com.capg.corejava.vikas;

public class Test {

	public static void main(String[] args) {
		Lays l=new Lays();
		Kurkure k=new Kurkure();
		Baby b= new Baby();
		b.receive(l);

	}

}
