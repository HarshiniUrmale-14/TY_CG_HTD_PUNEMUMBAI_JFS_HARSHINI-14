package com.capg.corejava.basics;

public class AssignmentOperator {

	public static void main(String[] args) {
		int i=10,j=20;
		i+=j;//i=i+j
		System.out.println(i);
		i-=j;//i=i-j
		System.out.println(i);
		i*=j;//i=i*j
		System.out.println(i);
		i/=j;//i=i/j
		System.out.println(i);
		i%=j;//i=i%j
		System.out.println(i);
		

	}

}
