package com.capg.corejava.vikas;

public class HDFC implements ATM {

	@Override
	public void validateCard() {
		System.out.println(" Validating card from HDFC DB");
		
	}

	@Override
	public void getInfo() {
		System.out.println(" Getting account holder info from HDFC DB");
		
	}

}
