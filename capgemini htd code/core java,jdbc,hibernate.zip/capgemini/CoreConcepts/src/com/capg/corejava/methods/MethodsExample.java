package com.capg.corejava.methods;

public class MethodsExample {
	static int b = 20;

	public static void main(String[] args) {

		print();
		int i = areaOfSquare(5);
		System.out.println("Area of Square=" + i);
		System.out.println(areaOfSquare(5));
		// int area=new MethodsExample().areaOfRect(2,5);
		// MethodsExample me1 = new MethodsExample();
		//int area=me1.areaOfRect(2,5);
		// System.out.println(area);
		 
		System.out.println(new MethodsExample().areaOfRect(3, 5));

	}

	public static void print() {
		System.out.println("print() method");
	}

	public static int areaOfSquare(int side) {
		// int area=side*side;return area;
		return side * side;
	}

	public int areaOfRect(int length, int width) {
		return length * width;
	}
}
