package com.capg.corejava.vikas;

public interface ATM {
void validateCard();
void getInfo();

}
