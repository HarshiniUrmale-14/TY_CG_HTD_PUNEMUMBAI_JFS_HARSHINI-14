package com.capg.corejava.methods;

public class Demo {

	static MethodsExample me = new MethodsExample();

	public static void main(String[] args) {
		System.out.println(me);
		MethodsExample me1 = new MethodsExample();// inside main method we can create
		// object without using static keyword
		System.out.println(me1);
		me.print();
		MethodsExample.print();
		int area=MethodsExample.areaOfSquare(6);
		System.out.println(area);
		System.out.println(me.areaOfRect(6, 7));
		System.out.println(me1.areaOfRect(5, 4));
		int r=me.b;
		System.out.println(r);
		
	
		
	}

}
