package com.capgemini.sorting.setExample;

public class Employee1 implements Comparable<Employee1> {

	int id;
	String name;
	double salary;

	public Employee1 (int id, String name, double salary) {

		this.id = id;
		this.name = name;
		this.salary = salary;
	}
	
	
	@Override
	public int compareTo(Employee1 s) {
		Integer k=this.id;
		Integer t=s.id;
		return k.compareTo(t);
	}
}
