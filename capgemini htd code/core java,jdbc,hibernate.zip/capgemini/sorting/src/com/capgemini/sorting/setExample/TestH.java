package com.capgemini.sorting.setExample;

import java.util.TreeSet;

public class TestH {

	
		public static void main(String[] args) {

			TreeSet<String> ts = new TreeSet<String>();
			ts.add("Tina");
			ts.add("Meena");
			ts.add("Leena");
			ts.add("kiara");

			System.out.println("*****using for-each loop******");
			for (String r : ts) {
				System.out.println(r);
			}
			
			

	}

}
