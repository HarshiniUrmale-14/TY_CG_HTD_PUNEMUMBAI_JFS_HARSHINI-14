package com.capgemini.sorting.setExample;

import java.util.Iterator;
import java.util.TreeSet;

public class BankTest {

	
	public static void main(String[] args) {
		
		ById comp=new ById();
		ByName comp1=new ByName();
		ByMICR comp2=new ByMICR();
		

		TreeSet<Bank> ts=new TreeSet<Bank>(comp2);

		Bank b1=new Bank(56567,"ICICI Banglore",223344l);
		Bank b2=new Bank(34526,"SBI",445566l);
		Bank b3=new Bank(99887,"Axis",112233l);
		Bank b4=new Bank(22341,"HDFC",332211l);

		ts.add(b1);
		ts.add(b2);
		ts.add(b3);
		ts.add(b4);

		Iterator<Bank> it=ts.iterator();

		while(it.hasNext()) {
			Bank b=it.next();
			System.out.println("Pin is "+b.pin);
			System.out.println("Name is "+b.name);
			System.out.println("MICR is "+b.micr);
			System.out.println("----------------------");
		}


	}

}
