package com.capgemini.modifiers.unclefamily;

public class TestB {

	public static void main(String[] args) {
		StringBuilder sb = new StringBuilder();
		sb.append("Safura");
		System.out.println(sb);

		StringBuilder sb1 = new StringBuilder("Sumayya");

		System.out.println(sb1);

	}

}
