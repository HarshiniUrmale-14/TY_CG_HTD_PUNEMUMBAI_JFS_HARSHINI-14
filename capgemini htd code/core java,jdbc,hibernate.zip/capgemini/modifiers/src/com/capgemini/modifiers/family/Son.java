package com.capgemini.modifiers.family;

public class Son {
void use() {
	Father f=new Father();
	
	//f.atm(); we cannot access private member outside class
	f.car();
	f.bike();
	f.cycle();
	
	
}
}
