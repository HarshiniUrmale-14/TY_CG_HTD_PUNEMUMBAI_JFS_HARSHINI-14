package com.capgemini.modifiers.family;

public class Father {
	private void atm() {
		System.out.println("I am private atm()");
	}

	void car() {
		System.out.println("I am default car()");
	}

	protected void bike() {
		System.out.println("I am protected bike()");
	}

	public void cycle() {
		System.out.println("I am public cycle()");
	}

	void use() {

		atm();
		car();
		bike();
		cycle();

	}
}
