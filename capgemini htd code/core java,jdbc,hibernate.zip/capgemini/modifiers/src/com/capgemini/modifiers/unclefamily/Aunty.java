package com.capgemini.modifiers.unclefamily;

import com.capgemini.modifiers.family.Father;

public class Aunty extends Father {
	void use() {
		//atm(); we cannot access private member outside class
		//car(); we cannot access defaut member outside package
		bike();
		cycle();
	}

}
