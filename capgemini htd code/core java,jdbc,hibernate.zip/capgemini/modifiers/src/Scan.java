import java.util.Scanner;

public class Scan {
	public static void main(String[] args) {

		try (Scanner sc = new Scanner(System.in);
				Scanner sc1 = new Scanner(System.in);
				Scanner sc2 = new Scanner(System.in);
				Scanner sc3 = new Scanner(System.in)) {
			
			System.out.println("Enter the age");
			int age = sc.nextInt();

			System.out.println(age);

		}
	}

}
