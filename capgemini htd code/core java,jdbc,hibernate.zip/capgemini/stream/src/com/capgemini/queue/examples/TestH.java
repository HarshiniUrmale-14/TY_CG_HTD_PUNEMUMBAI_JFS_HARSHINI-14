package com.capgemini.queue.examples;

import java.util.ArrayList;
import java.util.Comparator;

public class TestH {

	public static void main(String[] args) {

ArrayList<Integer> al=new ArrayList<Integer>();
		
		al.add(6);
		al.add(15);
		al.add(16);
		al.add(18);
		al.add(4);
		
		
		Comparator<Integer> comp=(i,j)->i.compareTo(j);
		
		Integer small=al.stream().min(comp).get();
		System.out.println("Smallest number is "+small);
		Integer large=al.stream().max(comp).get();
		System.out.println("Largest number is "+large);
		
	}

}
