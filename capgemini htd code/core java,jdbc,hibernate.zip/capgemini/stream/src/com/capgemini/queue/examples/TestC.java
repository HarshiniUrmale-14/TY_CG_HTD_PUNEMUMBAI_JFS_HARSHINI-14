package com.capgemini.queue.examples;

import java.util.Iterator;
import java.util.PriorityQueue;

public class TestC {

	public static void main(String[] args) {

		PriorityQueue<Integer> p=new PriorityQueue<Integer>();
		
		p.add(9);
		p.add(5);
		p.add(4);
		p.add(10);
		
		p.offer(15);
		
		Iterator<Integer> it=p.iterator();
		
		while(it.hasNext()) {
			Integer r=it.next();
			System.out.println(r);
		}
	}

}
