package com.capgemini.functioninterfaceExample;

import java.util.ArrayList;
import java.util.function.Predicate;

public class TestStudent {
	public static void main(String[] args) {
		
	
	
	Student s1=new Student(1,"Raju",24.56);
	Student s2=new Student(2,"Rahul",56.56);
	Student s3=new Student(3,"Rani",24.56);
	
	
	
	Predicate<Student> p=i->{
		
		if(i.percentage>=35) {
			return true;
		}else {
			return false;
		}
		};
		
		boolean  b=p.test(s1);
		System.out.println("Result is "+b);
		
		boolean  b1=p.test(s2);
		System.out.println("Result is "+b1);
		
	}
}
