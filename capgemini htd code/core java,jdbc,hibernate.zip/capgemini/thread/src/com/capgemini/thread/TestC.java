package com.capgemini.thread;

public class TestC {
	public static void main(String[] args) {
		System.out.println("main started.....");
		PVR a=new PVR();
		
		Paytm t1=new Paytm(a);
		t1.setDaemon(true);
		t1.start();
		
		Paytm t2=new Paytm(a);
		t2.start();
		
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		System.out.println("main ended....");
		
	
		
	}

}
