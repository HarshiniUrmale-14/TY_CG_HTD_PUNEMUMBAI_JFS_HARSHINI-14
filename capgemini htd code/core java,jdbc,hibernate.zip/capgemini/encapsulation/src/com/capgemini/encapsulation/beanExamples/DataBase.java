package com.capgemini.encapsulation.beanExamples;

public class DataBase {

	void receive (Student t){
		System.out.println("**I am database**");
		System.out.println("Id is "+t.getId());
		System.out.println("Name is "+t.getName());
		System.out.println("Height is "+t.getHeight());
		
	}
	void receive (Employee e) {
		System.out.println("**I am database of Employee**");
		System.out.println("Id is "+e.getId());
		System.out.println("Name is "+e.getEname());
	}
}
