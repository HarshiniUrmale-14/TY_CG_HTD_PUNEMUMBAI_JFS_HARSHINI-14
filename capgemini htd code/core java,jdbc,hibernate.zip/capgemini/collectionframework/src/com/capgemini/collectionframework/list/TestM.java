package com.capgemini.collectionframework.list;

import java.util.ArrayList;
import java.util.ListIterator;

public class TestM {

	public static void main(String[] args) {

		ArrayList<String> als=new ArrayList<String>();
		
		als.add("Sonu");
		als.add("Monu");
		als.add("Tonu");
		als.add("Sonu");
		
		ListIterator<String> lis=als.listIterator();
		
		System.out.println("------------Forward");
		while(lis.hasNext()) {
			String s=lis.next();
			System.out.println(s);
		}
		
		System.out.println("------------Backward");
		while(lis.hasPrevious()) {
			String r=lis.previous();
			System.out.println(r);
		}
		
	}

}
