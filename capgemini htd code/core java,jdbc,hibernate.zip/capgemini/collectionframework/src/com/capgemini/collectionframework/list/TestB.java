package com.capgemini.collectionframework.list;

import java.util.ArrayList;

public class TestB {
	public static void main(String[] args) {

		ArrayList al = new ArrayList();

		al.add(1221);
		al.add("chinnu");
		al.add(2.9);
		al.add('F');

		for (Object o : al) {
			System.out.println(o);

		}

	}
}
