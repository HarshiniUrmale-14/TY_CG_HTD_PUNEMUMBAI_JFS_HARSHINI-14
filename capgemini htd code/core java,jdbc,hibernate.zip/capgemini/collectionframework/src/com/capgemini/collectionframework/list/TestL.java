package com.capgemini.collectionframework.list;

import java.util.ArrayList;
import java.util.Iterator;

public class TestL {

	public static void main(String[] args) {

		ArrayList<Double> ald = new ArrayList<Double>();
		ald.add(2.1232);
		ald.add(23.45);
		ald.add(234.43);
		ald.add(5.44);
		
		Iterator<Double> itd=ald.iterator();
		
		while(itd.hasNext()) {
			Double r=itd.next();
			System.out.println(r);
		}
	}

}
