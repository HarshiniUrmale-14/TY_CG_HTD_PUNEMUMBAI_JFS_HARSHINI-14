package com.capgemini.collectionframework.list;

import java.util.ArrayList;
import java.util.ListIterator;

public class TestF {

	public static void main(String[] args) {

		ArrayList al=new ArrayList();
		al.add(24);
		al.add("chinnu");
		al.add(2.9);
		al.add('F');
		
		ListIterator li=al.listIterator();
		
		System.out.println("----------------Forward");
		
		while(li.hasNext()) {
			Object r=li.next();
			System.out.println(r);
		}
		
		System.out.println("----------------Backward");
		while(li.hasPrevious()) {
			Object s=li.previous();
			System.out.println(s);
		}
	}

}
