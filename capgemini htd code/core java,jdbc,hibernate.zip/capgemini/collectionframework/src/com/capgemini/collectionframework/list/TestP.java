package com.capgemini.collectionframework.list;

import java.util.Iterator;
import java.util.ListIterator;
import java.util.Vector;

public class TestP {

	public static void main(String[] args) {

		Vector v = new Vector();
		
		v.add(9.6);
		v.add('M');
		v.add("Priya");
		v.add(2);
		
		System.out.println("****************for loop***************");

		for (int i = 0; i < 4; i++) {
			Object r = v.get(i);
			System.out.println(r);
		}

		System.out.println("****************for-each loop***************");

		for (Object r : v) {
			System.out.println(r);
		}

		System.out.println("****************Iterator***************");

		Iterator it = v.iterator();

		while (it.hasNext()) {
			Object r = it.next();
			System.out.println(r);
		}

		System.out.println("****************ListIterator***************");

		ListIterator lit = v.listIterator();

		System.out.println("------------Forward");
		while (lit.hasNext()) {
			Object s = lit.next();
			System.out.println(s);
		}

		System.out.println("------------Backward");
		while (lit.hasPrevious()) {
			Object r = lit.previous();
			System.out.println(r);
		}



	}

}
