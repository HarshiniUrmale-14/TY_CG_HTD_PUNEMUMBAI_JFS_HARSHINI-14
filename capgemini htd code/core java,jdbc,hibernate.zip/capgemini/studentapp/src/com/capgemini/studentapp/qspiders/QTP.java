package com.capgemini.studentapp.qspiders;

public class QTP {
	public void teachQTP() {
		System.out.println("I am teach QTP Method");
	}

}
