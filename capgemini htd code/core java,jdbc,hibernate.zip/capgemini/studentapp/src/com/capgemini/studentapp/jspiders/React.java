package com.capgemini.studentapp.jspiders;

public class React {
	public void teachReact() {
		System.out.println("I am teach React Method");
	}

}
