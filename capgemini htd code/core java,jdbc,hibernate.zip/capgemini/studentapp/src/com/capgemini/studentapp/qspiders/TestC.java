package com.capgemini.studentapp.qspiders;

import com.capgemini.studentapp.jspiders.Remote;

public class TestC {

	public static void main(String[] args) {
	Remote.on();
	System.out.println(Remote.sum);
	
	Remote R=new Remote();
	Remote.off();

	System.out.println(R.count);

	

	}

}
