 package com.capgemini.studentapp.jspiders;

public class Angular {
	public void teachAngular() {
		System.out.println("I am teach Angular Method");
	}

}
