package com.capgemini.colllection.ALpassingToMethod;

import java.util.ArrayList;



public class StudentTest {
	public static void main(String[] args) {
		
		ArrayList<Student> als=new ArrayList<Student>();
		
		Student s1 = new Student(1, "Sumayya", 83.23);
		Student s2 = new Student(2, "Simran", 81.23);
		Student s3 = new Student(3, "Safura", 84.23);
		Student s4 = new Student(4, "Vajid", 85.23);
		
		
		als.add(s1);
		als.add(s2);
		als.add(s3);
		als.add(s4);
		
		Helper h=new Helper();
		
		h.display(als);
		
		h.onlyPass(als);
		
		h.distinction(als);
		

		
	}

}
