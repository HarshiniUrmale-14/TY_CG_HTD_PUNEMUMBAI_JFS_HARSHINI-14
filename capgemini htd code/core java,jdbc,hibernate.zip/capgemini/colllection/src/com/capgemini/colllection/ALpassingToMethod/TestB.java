package com.capgemini.colllection.ALpassingToMethod;

import java.util.ArrayList;

public class TestB {

	public static void main(String[] args) {

		ArrayList<Double> ald=new ArrayList<Double>();
		
		ald.add(3.6);
		ald.add(2.4);
		ald.add(4.7);
		ald.add(1.6);
		
		ArrayList<Double> bld=new ArrayList<Double>();
		
		bld.add(29.4);
		bld.add(16.2);
		
		System.out.println("Before-------------"+ald);
		
		ald.addAll(bld);
		System.out.println("After-------------"+ald);
		
		boolean a=ald.containsAll(bld);
		System.out.println(a);
		System.out.println("After-------------"+ald);
		
		ald.removeAll(bld);
		
		System.out.println("After-------------"+ald);
		
		
		
		
		
	}

}
