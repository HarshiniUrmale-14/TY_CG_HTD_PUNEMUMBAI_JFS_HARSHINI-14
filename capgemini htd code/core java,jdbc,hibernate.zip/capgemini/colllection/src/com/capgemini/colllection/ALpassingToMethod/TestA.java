package com.capgemini.colllection.ALpassingToMethod;

import java.util.ArrayList;

public class TestA {
	
	public static void main(String[] args) {
		
	
	
	ArrayList<Double> ald=new ArrayList<Double>();
	
	ald.add(3.6);
	ald.add(2.4);
	ald.add(4.7);
	ald.add(1.6);
	
	
	System.out.println("Before------->"+ald);
	
	ald.add(3.4);
	System.out.println("After------->"+ald);
	
	ald.add(2,9.6);
	System.out.println("After------->"+ald);
	
	Double d=ald.set(3, 6.6);
	System.out.println("Removed object is "+d);
	System.out.println("After------->"+ald);
	
	Double e=ald.remove(1);
	System.out.println("Removed object is "+e);
	System.out.println("After------->"+ald);
	
	boolean f=ald.remove(6.6);
	System.out.println(f);
	System.out.println("After------->"+ald);
	
	boolean g=ald.contains(4.7);
	System.out.println(g);
	System.out.println("After------->"+ald);
	
	ald.clear();
	System.out.println("After------->"+ald);
	
	
	
	
	
	
	
	
	
	
	

	}
}
