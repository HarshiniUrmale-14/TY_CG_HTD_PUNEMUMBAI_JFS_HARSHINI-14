package com.capgemini.objectclass.methods;

public class TestC {
	public static void main(String[] args) {
		Student a = new Student(1, "Simran", 83);
		System.out.println(a);

		Employee b = new Employee(1, "Simran", 20000, 'F');
		System.out.println(b);
	}
}
