package com.capgemini.objectclass.methods;

public class TestD {

	public static void main(String[] args) {
		Cow c= new Cow();
		c.id=1;
		c.name="Ganga";
		c.height=3.6;
		
		Cow d= new Cow();
		d.id=2;
		d.name="Tanga";
		d.height=3.6;
		
		Cow e= new Cow();
		e.id=1;
		e.name="Ganga";
		e.height=3.6;
		
		System.out.println(c.equals(d));
		System.out.println(c.equals(e));
		
		
		
		

	}

}
