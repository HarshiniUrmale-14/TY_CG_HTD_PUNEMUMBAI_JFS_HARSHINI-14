package com.capgemini.objectclass.methods;

public class TestB {
	public static void main(String[] args) {
		Pen P = new Pen();
		System.out.println(P);

		System.out.println(P.hashCode());

		String r = P.toString();
		System.out.println(r);

	}

}
