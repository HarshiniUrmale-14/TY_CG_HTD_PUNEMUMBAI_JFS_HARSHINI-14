package com.capgemini.maps;

import java.util.HashMap;
import java.util.Map;

public class TestA {

	public static void main(String[] args) {
		
		HashMap<String,Integer> hm=new HashMap<String,Integer>();
		
		hm.put("Ondhu", 1);
		hm.put("Idhu", 5);
		hm.put("Hattu", 10);
		hm.put("Eredu", 2);
		
		for(Map.Entry<String,Integer> me :hm.entrySet()) {
			String k=me.getKey();
			Integer t=me.getValue();
		System.out.println("Key is "+k);
		System.out.println("Value is "+t);
		System.out.println("--------------------------");
			
		}
		
	}

}
