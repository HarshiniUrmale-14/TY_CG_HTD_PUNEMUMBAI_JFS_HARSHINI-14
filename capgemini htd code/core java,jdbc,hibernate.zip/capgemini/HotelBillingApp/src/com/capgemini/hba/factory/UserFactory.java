package com.capgemini.hba.factory;

import com.capgemini.hba.dao.UserDAO;
import com.capgemini.hba.dao.UserDAOJDBCImpl;

public class UserFactory {
	
	private UserFactory() {
		
	}
	
	public static UserDAO getInstance() {
		
		UserDAO dao=new UserDAOJDBCImpl();
		
		return dao;
	}

}
