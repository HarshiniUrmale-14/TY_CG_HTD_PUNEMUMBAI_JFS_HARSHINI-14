package com.capgemini.hba.controler;

import java.util.List;
import java.util.Scanner;

import com.capgemini.hba.bean.UserBean;
import com.capgemini.hba.dao.UserDAO;
import com.capgemini.hba.factory.UserFactory;

public class HotelMain {

	public static void main(String[] args) {

		UserDAO user = UserFactory.getInstance();
		Scanner sc = new Scanner(System.in);

		System.out.println("Press 1 to show all food items");
		System.out.println("Press 2 to take order from customers");
		System.out.println("Press 3 to operate on food items");
		System.out.println("Press 4 to total bill of the day");
		System.out.println("Select the button and enter it");

		int button = Integer.parseInt(sc.nextLine());
		switch (button) {
		case 0: {
			System.out.println("Welcome to Hotel Billing Application");
		}
		case 1: {
			List<UserBean> user1 = user.getAllInfo();
			break;
		}
		case 2: {
			System.out.println("Enter how many meny you want");
			int count = Integer.parseInt(sc.nextLine());
			for (int a = 1; a <= count; a++) {
				System.out.println("Enter food itemCode");
				int i = Integer.parseInt(sc.nextLine());
				UserBean user1 = user.getOrderFromUser(i);

			}
			break;
		}
		case 3: {
			System.out.println("Enter A to add food item");
			System.out.println("Enter B to remove food items");
			System.out.println("Enter C to operate on food items");
			System.out.println("Enter the key");
			String ch = sc.nextLine();

			switch (ch) {

			case "A": {
				System.out.println("enter the food item code");
				int i = Integer.parseInt(sc.nextLine());
				System.out.println("enter the food name");
				String s = sc.nextLine();
				System.out.println("enter the price ");
				Double d = Double.parseDouble(sc.nextLine());
				UserBean user1 = user.addFoodItem(i, s, d);
				break;
			}
			case "B": {
				System.out.println("Enter food item code which you want to remove");
				int i = Integer.parseInt(sc.nextLine());
				UserBean user1 = user.removeFoodItem(i);
				break;
			}
			case "C": {
				System.out.println("Ente the item code which you want to update");
				int i = Integer.parseInt(sc.nextLine());
				System.out.println("Enter price");
				Double d = Double.parseDouble(sc.nextLine());
				UserBean user2 = user.operateFood(i, d);
				break;
			}
			default:
				System.out.println("Please Enter valid character ");
			}
			break;
		}
		case 4: {
			System.out.println("Select number of items for billing");
			int count = Integer.parseInt(sc.nextLine());
			UserBean user1 = user.totalBill(count);
			break;
		}
		default:
			System.out.println("Please enter the valid number");
		}
	}

}
