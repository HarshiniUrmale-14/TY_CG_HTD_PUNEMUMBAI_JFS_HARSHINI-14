package com.capgemini.hba.dao;

import java.util.List;

import com.capgemini.hba.bean.UserBean;

public interface UserDAO {
	
	public List<UserBean> getAllInfo();
	public UserBean getOrderFromUser(int itemCode);
	public UserBean addFoodItem(int itemCode,String foodName,double price);
	public UserBean removeFoodItem(int itemCode);
	public UserBean operateFood(int itemCode,double price);
	public UserBean totalBill(int count);
	
	
	
	

}
