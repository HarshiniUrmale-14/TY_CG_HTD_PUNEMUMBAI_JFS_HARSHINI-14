package com.capgemini.jdbc;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class MyFirstJDBC {

	public static void main(String[] args) {
		Connection conn = null;
		Statement stmt = null;
		ResultSet res = null;
		try {
			Driver driver = new com.mysql.jdbc.Driver();
			DriverManager.registerDriver(driver);
			System.out.println("Driver loaded........");
			System.out.println("**********************************");

			// Get the DB connection via Driver
			String dbURL = "jdbc:mysql://localhost:3306/capg_db?user=J2EE&password=tiger";
			conn = DriverManager.getConnection(dbURL);
			System.out.println("connection established..........");
			System.out.println("******************************");

			// Issue SQL queries via connection
			String query = "select * from users_info";
			stmt = conn.createStatement();
			res = stmt.executeQuery(query);

			// Process the results returned by the SQL query
			while (res.next()) {
				System.out.println("User id: " + res.getInt(1));
				System.out.println("User name : " + res.getString("username"));
				System.out.println("Email is: " + res.getString("email"));
				System.out.println("Password is: " + res.getString("password"));
				System.out.println("******************************");
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (res != null) {
				try {
					res.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}

}
