package com.capgemini.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TestA {

	public static void main(String[] args) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		Scanner sc = new Scanner(System.in);

		try {
			// Load the driver
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver loaded.............");
			System.out.println("********************************");

			// Get the connection
			String dbURL = "jdbc:mysql://localhost:3306/capg_db?user=J2EE&password=tiger";
			DriverManager.getConnection(dbURL);
			conn = DriverManager.getConnection(dbURL);
			System.out.println("connection established..........");
			System.out.println("***************");

			// Issue SQL queries via connection
			String query = "insert into users_info values(?,?,?,?)";
			pstmt = conn.prepareStatement(query);

			System.out.println("Enter userid........");
			String id = sc.nextLine();
			Pattern pat = Pattern.compile("\\d{7}");
			Matcher mat = pat.matcher(id);
			boolean b = mat.matches();
			if (b == true) {
				pstmt.setString(1, id);
			} else {
				System.out.println("please enter id  according to the format");
			}

			System.out.println("Enter username......");
			String name=sc.nextLine();
			Pattern pat1=Pattern.compile("\\w+\\s\\w+");
			Matcher mat1=pat1.matcher(name);
			boolean b1=mat1.matches();
			if(b1==true) {
				pstmt.setString(2, name);
			}
			else {
				System.out.println("please enter name according to format");
			}
			
			System.out.println("Enter email.........");
			String mail = sc.nextLine();
			Pattern pat2 = Pattern.compile("\\w{1,10}\\@\\w{1,5}\\.\\w{1,3}");
			Matcher mat2 = pat2.matcher(mail);
			boolean b2 = mat2.matches();
			if (b2 == true) {
				pstmt.setString(3, mail);
			} else {
				System.out.println("please enter according to the format");
			}
			
			System.out.println("Enter password......");
			String pass=sc.nextLine();
			Pattern pat3=Pattern.compile("\\w+\\W\\d+");
			Matcher mat3=pat3.matcher(pass);
			boolean b3=mat3.matches();
			if(b3==true) {
				pstmt.setString(4, sc.nextLine());
			}
			else {
				System.out.println("please enter password according to the format````");
			}
			

			int count = pstmt.executeUpdate();

			// process the result
			if (count > 0) {
				System.out.println("Data inserted");
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			sc.close();
		}

	}

}
