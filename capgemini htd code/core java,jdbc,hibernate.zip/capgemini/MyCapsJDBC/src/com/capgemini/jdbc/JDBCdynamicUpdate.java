package com.capgemini.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class JDBCdynamicUpdate {

	public static void main(String[] args) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		Scanner sc = new Scanner(System.in);
		try {
			// load the Driver
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver loaded.............");
			System.out.println("********************************");

			// Get the connection
			String dbURL = "jdbc:mysql://localhost:3306/capg_db?user=J2EE&password=tiger";
			conn = DriverManager.getConnection(dbURL);
			System.out.println("connection established..........");
			System.out.println("***************");

			// Issue SQL queries via connection
			String query = "update users_info set username=?,email=?,password=? where userid=?";
			pstmt = conn.prepareStatement(query);
			System.out.println("Enter username......");
			pstmt.setString(1, sc.nextLine());
			System.out.println("Enter email.........");
			pstmt.setString(2, sc.nextLine());
			System.out.println("Enter password......");
			pstmt.setString(3, sc.nextLine());
			System.out.println("enter userid/..... ");
			pstmt.setInt(4, Integer.parseInt(sc.nextLine()));

			int count = pstmt.executeUpdate();

			// process the result
			if (count > 0) {
				System.out.println("Data updated");
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			sc.close();
		}

	}

}
