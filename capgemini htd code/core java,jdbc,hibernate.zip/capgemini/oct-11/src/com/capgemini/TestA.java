package com.capgemini;

import java.util.TreeSet;

public class TestA {
	
	

	public static void main(String[] args) {
		ByName comp=new ByName();
		ById comp1=new ById();

		TreeSet<Student> ts = new TreeSet<Student>(comp);

		Student s1 = new Student();
		s1.setName("Asha");
		s1.setId(1);
		s1.setPercentage(45.65);
		s1.setGender('F');

		Student s2 = new Student();
		s2.setName("Nikhil");
		s2.setId(2);
		s2.setPercentage(67.65);
		s2.setGender('M');

		Student s3 = new Student();
		s3.setName("Nisha");
		s3.setId(3);
		s3.setPercentage(76.65);
		s3.setGender('F');

		Student s4 = new Student();
		s4.setName("Geeta");
		s4.setId(4);
		s4.setPercentage(78.65);
		s4.setGender('F');

		Student s5 = new Student();
		s5.setName("Surya");
		s5.setId(5);
		s5.setPercentage(54.89);
		s5.setGender('M');

		ts.add(s1);
		ts.add(s1);
		ts.add(s1);
		ts.add(s1);
		ts.add(s1);

		for (Student s : ts) {
			System.out.println("Name is " + s.getName());
			System.out.println("ID is" + s.getId());
			System.out.println("Percentage is " + s.getPercentage());
			System.out.println("Gender is " + s.getGender());
			System.out.println("-------------------");

		}

	}

}
