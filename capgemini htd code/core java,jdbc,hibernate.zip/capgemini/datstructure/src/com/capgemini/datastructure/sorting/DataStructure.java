package com.capgemini.datastructure.sorting;

import java.time.Duration;
import java.time.Instant;

public class DataStructure {
	public static void main(String[] args) {
	bubble();
	insertion();
	selection();
	
	}
	public static void bubble() {
		
		int a[] = { 6, 9, 4, 8, 2, 3 };
		System.out.println("....................................");
		Instant start = Instant.now();
		BubbleSort.bubbleSort(a);
	
		System.out.println("Array After Bubble Sort");
		  for(int i=0; i < a.length; i++){  
              System.out.print(a[i] + "\n" );  
      }  
		  Instant end = Instant.now();
			long duration = Duration.between(start, end).toMillis();
			double seconds = duration / 1000.0;
			System.out.println("add time is" + seconds);
	}
	public static void insertion() {
		int a[] = { 6, 9, 4, 8, 2, 3 };
		System.out.println(".......................................");
		Instant start = Instant.now();
		InsertionSort.insertionSort(a);
		System.out.println("Array After insertion Sort");
		for (int i = 0; i < a.length; i++) {
			System.out.print(a[i] + " \n");
		}
		 Instant end = Instant.now();
			long duration = Duration.between(start, end).toMillis();
			double second = duration / 1000.0;
			System.out.println("add time is" + second);
	}
	public static void selection() {
		int a[] = { 6, 9, 4, 8, 2, 3 };
		System.out.println("...........................................");
		Instant start = Instant.now();
		SelectionSort.selectionSort(a);
		System.out.println("Array After selection Sort");
		for (int i = 0; i < a.length; i++) {
			System.out.print(a[i] + " \n");
		}
		 Instant end = Instant.now();
			long duration = Duration.between(start, end).toMillis();
			double second = duration / 1000.0;
			System.out.println("add time is" + second);
	}
	}


