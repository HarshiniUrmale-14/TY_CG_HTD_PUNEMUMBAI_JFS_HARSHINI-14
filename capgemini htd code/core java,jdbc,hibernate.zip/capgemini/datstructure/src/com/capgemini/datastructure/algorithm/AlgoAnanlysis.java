package com.capgemini.datastructure.algorithm;

import java.time.Duration;
import java.time.Instant;

public class AlgoAnanlysis {
	public static void main(String[] args) {
		/*
		 * long number=9999999L; System.out.println(add(number));
		 * System.out.println(addQuick(number));
		 */
		countingDuration1();
		countingDuration2();

	}

	public static long add(Long number) {
		long total = 0L;
		for (long i = 0; i <= number; i++) {
			total = total + i;

		}
		return total;
	}

	public static long addQuick(Long number) {
		return number * (number + 1) / 2;
	}

	public static void countingDuration1() {
		long number = 99999999999999L;
		Instant start = Instant.now();// class store the time of start
		System.out.println(add(number));
		Instant end = Instant.now();// end time
		long duration = Duration.between(start, end).toMillis();
		double second = duration / 1000;
		System.out.println("add time is" + second);
	}

	public static void countingDuration2() {
		long number = 99999999999999L;
		Instant start = Instant.now();// class store the time of start
		System.out.println(addQuick(number));
		Instant end = Instant.now();// end time
		long duration = Duration.between(start, end).toMillis();
		double second = duration / 1000;
		System.out.println("add time is" + second);
	}
}
