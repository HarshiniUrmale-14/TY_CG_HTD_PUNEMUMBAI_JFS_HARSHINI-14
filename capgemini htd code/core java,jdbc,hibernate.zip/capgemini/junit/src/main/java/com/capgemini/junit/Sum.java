package com.capgemini.junit;

public class Sum {

	public int add(int a, int b) {
		return a + b;
	}

	public int addNum(int a, int b, int c) {
		return a + b + c;
	}

	public int fact(int a) {
		int fact = 1;
		while (a > 0) {
			fact = a * fact;
			a--;
		}
		return fact;
	}
}
