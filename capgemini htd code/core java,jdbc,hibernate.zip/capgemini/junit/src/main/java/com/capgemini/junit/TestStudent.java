package com.capgemini.junit;

public class TestStudent {

	public static void main(String[] args) {
Student s=new Student("abc",56,'f');
Student s1=new Student("abc",56,'m');
School sc=new School();
sc.registerStudent(null);


Student regstu=sc.registerStudent(s);
Student regstu2=sc.registerStudent(s1);
System.out.println("id is"+ regstu.getId() );
System.out.println("name is"+ regstu.getName());
System.out.println("*******************************");
System.out.println("id is"+regstu2.getId());
System.out.println("name is"+regstu2.getName());
	}

}
