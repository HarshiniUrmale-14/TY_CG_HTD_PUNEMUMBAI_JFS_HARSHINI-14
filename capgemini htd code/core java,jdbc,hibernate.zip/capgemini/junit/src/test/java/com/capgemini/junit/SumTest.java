package com.capgemini.junit;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class SumTest {

	@Test
	public void testSum() {
		Sum s = new Sum();
		int i = s.add(10, 20);
		assertEquals(30, i);
	}

	@Test
	public void testSumNum() {
		Sum s = new Sum();
		int i = s.addNum(10, 20, 30);
		assertEquals(60, i);
	}
	@Test
	public void testFact() {
		Sum s = new Sum();
		int i = s.fact(5);
		assertEquals(120, i);
	}
	@Test
	public void testFactForZero() {
		Sum s = new Sum();
		int i = s.fact(0);
		assertEquals(1, i);
	}
	@Test
	public void testFactForNegi() {
		Sum s = new Sum();
		int i = s.fact(-2);
		assertEquals(1, i);
	}

}
