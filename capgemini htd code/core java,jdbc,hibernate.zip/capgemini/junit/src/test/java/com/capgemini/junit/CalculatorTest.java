package com.capgemini.junit;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class CalculatorTest {
	Calculator calculator = null;
	@BeforeEach
	public void createObject() {
		calculator = new Calculator();
	}
	@Test
	public void testSum() {
		int i =calculator.add(10, 20);
		assertEquals(30, i);
	}
	@Test
	public void testSumNegi() {
		int i =calculator.add(-10, 20);
		assertEquals(10, i);
	}
	@Test
	public void testSub() {
		int i =calculator.sub(10,20);
		assertEquals(-10, i);
	}
	@Test
	public void testMul() {
		int i =calculator.mul(10, 20);
		assertEquals(200, i);
	}
	@Test
	public void testDiv() {
		assertThrows(ArithmeticException.class,()->calculator.div(10,0));
	}
}


