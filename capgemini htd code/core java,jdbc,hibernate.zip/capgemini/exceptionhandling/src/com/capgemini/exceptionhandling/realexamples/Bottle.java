package com.capgemini.exceptionhandling.realexamples;

import java.io.File;

public class Bottle {

	public void open() throws Exception //IOException, ClassNotFoundException
	{
		File f = new File("capgemini.text");

		f.createNewFile();
		
		Class.forName("com.capgemini.exceptionhandling.realexamples.Bottle");

	}

}
