package com.capgemini.exceptionhandling.examples;

public class TestA {
	public static void main(String[] args) {
		System.out.println("main started");

		int[] a = new int[3];

		try {
			System.out.println(a[7]);// it throw exception so we handle exception using try&catch block

		} catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("dont cross array boundry");
		}

		System.out.println("main ended");

	}
}
