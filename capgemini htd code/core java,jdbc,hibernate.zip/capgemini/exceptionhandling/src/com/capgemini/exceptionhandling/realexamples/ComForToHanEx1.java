package com.capgemini.exceptionhandling.realexamples;

import java.io.File;
import java.io.IOException;

public class ComForToHanEx1 {
	public static void main(String[] args) throws IOException {
		
		File f=new File("capgemini.text");
		
		f.createNewFile();
	}

}
