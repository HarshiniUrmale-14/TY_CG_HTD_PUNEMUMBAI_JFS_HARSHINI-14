package com.capgemini.exceptionhandling.realexamples;

public class Paytm {
	void book() {
		System.out.println("book started");

		IRCTC i = new IRCTC();
		try {
			i.confirm();
		} catch (ArithmeticException a) {
			System.out.println("Exception caught at book method");
		}
		System.out.println("book ended");
	}
}
