package com.capgemini.exceptionhandling.examples;

public class TestG {
	public static void main(String[] args) {
		System.out.println("main started");

		String s="simran";
		int[] a = new int[3];

		try {
			System.out.println(s.toUpperCase());
			System.out.println(a[2]);
			System.out.println(10/0);
		} catch (Exception e) {
			System.out.println("Sorry something went wrong");
		} 

		System.out.println("main ended");

}


}
