package com.capgemini.exceptionhandling.realexamples;

public class TestA {
	public static void main(String[] args) {
		System.out.println("main started");
		Paytm p = new Paytm();
		try {
			p.book();
		} catch (ArithmeticException a) {
			System.out.println("Exception caught at main method");
		}
		System.out.println("main ended");
	}
}
