package com.capgemini.exceptionhandling.realexamples;

public class IRCTC {
	void confirm() {
		System.out.println("confirm sarted");

		try {
			System.out.println(10 / 0);
		} catch (ArithmeticException a) {
			System.out.println("Exception caught at confirm method");
		}

		System.out.println("confirm ended");
	}
}
