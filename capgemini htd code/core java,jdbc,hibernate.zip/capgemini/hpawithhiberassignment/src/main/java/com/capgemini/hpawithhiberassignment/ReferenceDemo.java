package com.capgemini.hpawithhiberassignment;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.capgemini.hpawithhiberassignment.dto.Student;

public class ReferenceDemo {

	public static void main(String[] args) {

		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("Simran");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		
		
		Student data = entityManager.getReference(Student.class, 1);
	
		System.out.println("Id is " + data.getId());
		System.out.println("name is " + data.getName());
		System.out.println("Percentage is " + data.getPercentage());
	}

}
