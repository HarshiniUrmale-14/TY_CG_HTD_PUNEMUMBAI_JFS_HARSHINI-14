package com.capgemini.hpawithhiberassignment;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.capgemini.hpawithhiberassignment.dto.Student;

public class RetriveDemo {
	
	public static void main(String[] args) {
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("Simran");
		EntityManager em=emf.createEntityManager();
		String jpql="from Student";
		Query query=em.createQuery(jpql);
		List<Student> list=query.getResultList();
		
		for(Student s:list) {
		System.out.println(s.getId());
		System.out.println(s.getName());
		System.out.println(s.getPercentage());
		System.out.println("*************************");
		}
		
		
		
	}

}
