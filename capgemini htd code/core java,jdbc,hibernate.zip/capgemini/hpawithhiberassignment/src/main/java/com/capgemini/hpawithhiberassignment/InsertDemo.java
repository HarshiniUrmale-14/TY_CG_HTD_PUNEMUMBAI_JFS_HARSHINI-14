package com.capgemini.hpawithhiberassignment;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.capgemini.hpawithhiberassignment.dto.Student;

public class InsertDemo {

	public static void main(String[] args) {
		Student s=new Student();
		s.setId(7);
		s.setName("Polo");
		s.setPercentage(90);
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("Simran");
		EntityManager em=emf.createEntityManager();
		EntityTransaction tr=em.getTransaction();
		tr.begin();
		em.persist(s);
		System.out.println("data inserted");
		tr.commit();
		em.close();
		

	}

}
