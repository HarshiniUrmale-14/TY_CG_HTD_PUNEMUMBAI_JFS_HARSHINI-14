package com.capgemini.maps1;

public class Student {
	
	int id;
	String name;
	double percentage;
	char gender;
	
	public Student(int id, String name, double percentage, char gender) {
	
		this.id = id;
		this.name = name;
		this.percentage = percentage;
		this.gender = gender;
	}
	
	

}
