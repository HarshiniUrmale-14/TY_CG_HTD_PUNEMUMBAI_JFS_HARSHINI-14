package com.capgemini.maps1;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

public class Helper {

	void displayPassed(ArrayList<Student> al) {
		List li = al.parallelStream().filter(i -> i.percentage >= 35).collect(Collectors.toList());

		Iterator<Student> it = li.iterator();

		while (it.hasNext()) {
			Student s = it.next();
			System.out.println("Name is " + s.name);
			System.out.println("Id is " + s.id);
			System.out.println("Percentage is " + s.percentage);
			System.out.println("Gender is " + s.gender);
			System.out.println("---------------------------------");

		}
	}

	void displayFailed(ArrayList<Student> al) {
		List li = al.parallelStream().filter(i -> i.percentage < 35).collect(Collectors.toList());

		Iterator<Student> it = li.iterator();

		while (it.hasNext()) {
			Student s = it.next();
			System.out.println("Name is " + s.name);
			System.out.println("Id is " + s.id);
			System.out.println("Percentage is " + s.percentage);
			System.out.println("Gender is " + s.gender);
			System.out.println("---------------------------------");

		}
	}

	void displayPassedWithGender(ArrayList<Student> al, char g) {
		List li = al.parallelStream().filter(i -> i.percentage >= 35 && i.gender == g).collect(Collectors.toList());

		Iterator<Student> it = li.iterator();

		while (it.hasNext()) {
			Student s = it.next();
			System.out.println("Name is " + s.name);
			System.out.println("Id is " + s.id);
			System.out.println("Percentage is " + s.percentage);
			System.out.println("Gender is " + s.gender);
			System.out.println("---------------------------------");

		}
	}

	void displayFailedWithGender(ArrayList<Student> al, char g) {
		List li = al.parallelStream().filter(i -> i.percentage < 35 && i.gender == g).collect(Collectors.toList());

		Iterator<Student> it = li.iterator();

		while (it.hasNext()) {
			Student s = it.next();
			System.out.println("Name is " + s.name);
			System.out.println("Id is " + s.id);
			System.out.println("Percentage is " + s.percentage);
			System.out.println("Gender is " + s.gender);
			System.out.println("---------------------------------");

		}
	}

	Comparator<Student> comp = (o1, o2) -> {
		Double i = o1.percentage;
		Double j = o2.percentage;
		return i.compareTo(j);
	};

	void topper(ArrayList<Student> al) {

		Student s = al.stream().max(comp).get();
		System.out.println("Name is " + s.name);
		System.out.println("Id is " + s.id);
		System.out.println("Percentage is " + s.percentage);
		System.out.println("Gender is " + s.gender);
		System.out.println("---------------------------------");

	}

	void displayAll(ArrayList<Student> al) {

		Iterator<Student> it = al.iterator();

		while (it.hasNext()) {
			Student s = it.next();
			System.out.println("Name is " + s.name);
			System.out.println("Id is " + s.id);
			System.out.println("Percentage is " + s.percentage);
			System.out.println("Gender is " + s.gender);
			System.out.println("---------------------------------");
		}
	}

}
