package com.capgemini.regex;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PatternConcepts {

	static Pattern pattern;
	static Matcher matcher;

	public static void main(String[] args) {

		pattern = Pattern.compile("\\d");// it can match only one digit
		matcher = pattern.matcher("9");
		System.out.println("pattern \\d : " + matcher.matches());

		pattern = Pattern.compile("\\d+");// it can match any number of digits
		matcher = pattern.matcher("298340875957094948");
		System.out.println("pattern \\d+ : " + matcher.matches());

		pattern = Pattern.compile("\\d{10}");// it can match only 10  digits
		matcher = pattern.matcher("9359467647");
		System.out.println("pattern \\d{10} : " + matcher.matches());
		
		pattern = Pattern.compile("\\d{0}");
		matcher = pattern.matcher("");
		System.out.println("pattern \\d{} : " + matcher.matches());

		pattern = Pattern.compile("\\d{1,10}");// it can match between min 1 and max 10 digits
		matcher = pattern.matcher("9359467653");
		System.out.println("pattern \\d{1,10} : " + matcher.matches());
		
		pattern = Pattern.compile("\\D");// it can match other than one digit i.e it can match single char, single special symbol
		matcher = pattern.matcher("*");
		System.out.println("pattern \\D : " + matcher.matches());
		
		pattern = Pattern.compile("\\D");
		matcher = pattern.matcher("9");
		System.out.println("pattern \\D : " + matcher.matches());
		
		pattern = Pattern.compile("\\D+");// it can match other than digit
		matcher = pattern.matcher("93987");
		System.out.println("pattern \\D+ : " + matcher.matches());
		
		pattern=Pattern.compile("\\w");// it match single character and also a match single digit
		matcher=pattern.matcher("a");//a,A,1
		System.out.println("pattern \\w: "+matcher.matches());
		
		pattern=Pattern.compile("\\w+");// it can match set of character as well as digits
		matcher=pattern.matcher("simmi123");
		System.out.println("pattern \\w+: "+matcher.matches());
		
		pattern=Pattern.compile("\\W");//it can check other than digit and character, i.e. it will check only special symbol
		matcher=pattern.matcher("#");
		System.out.println("pattern \\W: "+matcher.matches());
		
		pattern=Pattern.compile("\\W");
		matcher=pattern.matcher("A");
		System.out.println("pattern \\W: "+matcher.matches());
		
		
		pattern=Pattern.compile("\\W+");// it match single character and also a match single digit
		matcher=pattern.matcher("!@#$%^&*()");
		System.out.println("pattern \\W+: "+matcher.matches());
		
		pattern=Pattern.compile("\\s");// it can match single space
		matcher=pattern.matcher(" ");
		System.out.println("pattern \\s: "+matcher.matches());
		
		pattern=Pattern.compile("\\s+");// it can match multiple space
		matcher=pattern.matcher("          ");
		System.out.println("pattern \\s+: "+matcher.matches());
		
		pattern=Pattern.compile("\\S");// it can match other than single space
		matcher=pattern.matcher("a ");
		System.out.println("pattern \\S: "+matcher.matches());
		
		
		
		
		
		
	}
}
