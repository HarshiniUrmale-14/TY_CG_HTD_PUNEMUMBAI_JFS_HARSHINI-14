
public class TestC {

	public static void main(String[] args) {
		System.out.println(Car.j);
		Car.m.play();
		Car.m.pause();
		Car.m.stop();
		Car obj=new Car();
		System.out.println(obj.i);
		
		
		

	}

}
