
public class TestB {

	public static void main(String[] args) {
		System.out.println(Room.i);
		Room.f.on();
		Room.f.off();
		

		}
}
