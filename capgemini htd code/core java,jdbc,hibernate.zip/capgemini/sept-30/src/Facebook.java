
public class Facebook {
	final void login(String email,double password) {
		System.out.println("login using gmail");
	}
	final void login(double num,double password) {
		System.out.println("login using number");
	}
	

}
