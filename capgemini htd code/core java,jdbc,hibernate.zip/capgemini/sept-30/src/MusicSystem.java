
public class MusicSystem {
	void play() {
		System.out.println("Music is played");
	}
	void pause() {
		System.out.println("Music is paused ");
	}
	void stop() {
		System.out.println("Music is stop");
	}

}
