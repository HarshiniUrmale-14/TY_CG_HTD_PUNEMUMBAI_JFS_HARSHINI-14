
public class Room {
static int i=20;
static Fan f=new Fan();


}
