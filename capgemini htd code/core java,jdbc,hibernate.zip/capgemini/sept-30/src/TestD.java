
public class TestD {

	public static void main(String[] args) {
		Train t=new Train();
	t.search(1686);

	}

}
