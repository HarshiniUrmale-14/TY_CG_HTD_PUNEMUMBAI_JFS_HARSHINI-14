
public class Car {
	
	static int j=20;
	int i=10;
	static  MusicSystem m=new MusicSystem();
	
	

}
