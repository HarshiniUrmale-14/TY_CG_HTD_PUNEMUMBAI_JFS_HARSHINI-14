
public class Fan {
void on() {
	System.out.println("Fan is ON");
}
void off() {
	System.out.println("Fan is OFF");
}


}
