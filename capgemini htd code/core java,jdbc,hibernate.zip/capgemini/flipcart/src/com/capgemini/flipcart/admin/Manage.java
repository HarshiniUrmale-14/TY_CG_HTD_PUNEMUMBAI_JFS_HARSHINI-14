package com.capgemini.flipcart.admin;

public class Manage {

}
