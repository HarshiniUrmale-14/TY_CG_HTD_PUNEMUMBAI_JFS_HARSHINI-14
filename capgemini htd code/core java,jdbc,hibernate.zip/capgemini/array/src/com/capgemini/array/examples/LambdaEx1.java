package com.capgemini.array.examples;

interface SQuare{
	int sqr(int a);
}


public class LambdaEx1 {
public static void main(String[] args) {
	
		SQuare f=a->a*a;
		int j=f.sqr(4);
		System.out.println(j);
	}
}
	

