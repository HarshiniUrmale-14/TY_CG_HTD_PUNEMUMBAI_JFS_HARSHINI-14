package com.capgemini.array.examples;

interface Value{
	double getPi();
}
public class Lambda4 {

	public static void main(String[] args) {
		
		Value a=()->3.142;
		double j =a.getPi();
		System.out.println(j);

	}
}
