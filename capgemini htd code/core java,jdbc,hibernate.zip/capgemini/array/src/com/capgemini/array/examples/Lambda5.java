package com.capgemini.array.examples;

interface Factorial{
	int fact(int n);
}
public class Lambda5  {
	public static void main(String[] args) {
		
	

	Factorial m=n->
	{
		if(n==0)
			return 1;
		if(n>0) {
		for(Integer i=1; i<=n;i++) {
			Integer f=m.fact(n)*i;
			return f;
		}
		
		}
		return 0;
	
		};
		int res=m.fact(5);
		System.out.println(res);
	
	}
}
