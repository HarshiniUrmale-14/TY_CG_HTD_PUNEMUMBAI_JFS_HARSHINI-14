package com.capgemini.array.examples;

interface Gm{
	void gm();
}
public class Lambda3 {
	public static void main(String[] args) {
		Gm g=()-> System.out.println("Good Morning") ;
		
		g.gm();
		
	}
	

}
