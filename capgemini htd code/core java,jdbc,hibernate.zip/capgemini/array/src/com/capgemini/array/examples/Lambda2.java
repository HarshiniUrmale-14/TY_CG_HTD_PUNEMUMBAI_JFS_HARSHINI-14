package com.capgemini.array.examples;

interface Circle{
	double area(double r);
}
public class Lambda2 {
	public static void main(String[] args) {
		double Pi=3.142;
		Circle a=r->2*Pi*r*r;
		
		double res=a.area(2.5);
		System.out.println("result is "+res);
		
	}

}
