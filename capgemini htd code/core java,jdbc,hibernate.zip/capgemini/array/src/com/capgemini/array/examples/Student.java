package com.capgemini.array.examples;

public class Student {
	int id;
	String name;
	double percentage; 

	public Student(int id, String name, double percentage) {
		super();
		this.id = id;
		this.name = name;
		this.percentage = percentage;
	}

	public static void main(String[] args) {
		Student[] st=new Student[4];
		Student s1=new Student(1,"Suma",93);
		Student s2=new Student(2,"Simmi",92);
		Student s3=new Student(3,"Safu",91);
		Student s4=new Student(4,"Vaju",90);
		
		st[0]=s1;
		st[1]=s2;
		st[2]=s3;
		st[3]=s4;
		
		receive(st);
	}
	
	static void receive(Student[] ar) {
		
		
		for(Student i:ar) {
			System.out.println(i.id);
			System.out.println(i.name);
			System.out.println(i.percentage);
			System.out.println("------------------------------- ");
			
			
		}
	}

}
