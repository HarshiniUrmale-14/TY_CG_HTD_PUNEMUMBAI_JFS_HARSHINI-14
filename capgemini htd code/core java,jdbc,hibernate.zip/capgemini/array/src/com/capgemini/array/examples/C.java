package com.capgemini.array.examples;

public class C {

	public static void main(String[] args) {
	int m[]= {1,2,3,4,5};
	double n[]= {1.1,1.2,1.3,1.4};
	String s[]= {"sim","ran"};
	receive(m);
	receive1(n);
	receive2(s);
	

	}
	static void receive(int a[]) {
		for(int i:a) {
			System.out.println(i);
		}
	}
	
	static void receive1(double a[]) {
		for(double j:a) {
			System.out.println(j);
			
		}
	}
		
		
		static void receive2(String a[]) {
			for(String k:a) {
				System.out.println(k);
				
			}
		
	}

}
