package com.capgemini.array.examples;

interface Sum{
	int add(int a,int b);
}
public class LambdaEX {
	public static void main(String[] args) {
		Sum f=(a,b)-> a+b;
		
		int j=f.add(10,50);
		
		System.out.println("Sum is"+j);
		
	}

}
