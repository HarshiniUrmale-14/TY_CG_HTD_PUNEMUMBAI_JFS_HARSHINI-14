package com.capgemini.array.examples;

public class A {

	public static void main(String[] args) {
		double[] d = new double[4];
		String[] s = new String[4];
		s[0] = "Sumayya";
		s[1] = "Simran";
		s[2] = "Safura";
		s[3] = "vajid";

		for (int j = 0; j < 4; j++) {
			System.out.println(s[j]);
		}

		int[] a = new int[4];
		a[0] = 1;
		a[1] = 2;
		a[2] = 3;
		a[3] = 4;
		for (int k = 0; k < a.length; k++) {
			System.out.println(a[k]);
		}

		int b[] = { 1, 2, 3, 4, 5, 6, 7 };
		for (int k = 0; k < b.length; k++) {
			System.out.println(b[k]);
		}

	}

}
