package com.capgemini.stringexp.one;

public class StrineMethodEx {

	public static void main(String[] args) {
		String x="abcabc";
		String w="defdef";
		byte[] y=x.getBytes();
		System.out.println(y[0]);
		
		String Z=x.replace( "ab", "h");
		System.out.println(x.replace(x,w));
		System.out.println(x.replaceFirst("a", "sim"));
		System.out.println(Z);
		
		char[] ch=x.toCharArray();
		System.out.println(ch);
		System.out.println(ch[0]);
 
		String k="  simran ";
		System.out.println(k.length());
		String l=k.trim();
		System.out.println(l);
		System.out.println(l.length());
		
		

	}

}
