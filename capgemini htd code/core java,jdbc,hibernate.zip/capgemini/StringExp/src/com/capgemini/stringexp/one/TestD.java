package com.capgemini.stringexp.one;

public class TestD {
	public static void main(String[] args) {
		String a="120";
		String b="50";
		System.out.println(a+b);
		int i=Integer.parseInt(a);
		int j=Integer.parseInt(b);
		System.out.println(i+j);
		
		String c="2.44";
		double d=Double.parseDouble(c);
		System.out.println(d);
		
		
	}

}
