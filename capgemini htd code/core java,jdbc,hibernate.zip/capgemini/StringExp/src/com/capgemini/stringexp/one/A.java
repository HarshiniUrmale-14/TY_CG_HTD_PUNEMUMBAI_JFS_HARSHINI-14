package com.capgemini.stringexp.one;

public interface A {
	void abc();
	 default void method() {
		
	}
	 static void test() {
		 
	 }
	 final int a=10;

}
