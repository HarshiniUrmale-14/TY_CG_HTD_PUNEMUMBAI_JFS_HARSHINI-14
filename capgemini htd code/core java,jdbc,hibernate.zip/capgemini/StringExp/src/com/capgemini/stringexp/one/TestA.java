package com.capgemini.stringexp.one;

public class TestA {

	public static void main(String[] args) {
		String a="Teju";
		String b="Dipu";
		a="Kavya";
		System.out.println("a is "+a);
		System.out.println("b is "+b);
		
		int num=a.length();
		System.out.println(num);
		
		boolean res= a==b;
		System.out.println("result is "+res);
		
		boolean res1=a.equals(b);
		System.out.println("result is "+res1);
		
		String c= " Simran  ";
		System.out.println(c.length());
		String d=c.trim();
		System.out.println(d.length());
		

	}

}
