package com.capgemini.jpawithhibernate.jpql;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class DeleteDynamicallyDemo {

	public static void main(String[] args) {
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("Simran");
		EntityManager em=emf.createEntityManager();
		EntityTransaction tr=em.getTransaction();
		String jpql="delete from Movie where id=:mid";
		tr.begin();
		Query query=em.createQuery(jpql);
		query.setParameter("mid", 6);
		int res=query.executeUpdate();
		System.out.println(res);
		tr.commit();
		em.close();
		

	}

}
