var Student = /** @class */ (function () {
    function Student(name, age, marks, degree) {
        this.name = name;
        this.age = age;
        this.marks = marks;
        this.degree = degree;
    }
    return Student;
}());
var student1 = new Student('priya', 99, 99); //object craetion-1
console.log(student1);
//student1.printDetails();
var student2 = {
    name: 'deepak',
    age: 45,
    marks: 64
};
console.log(student2);
var students = [
    new Student('Subrat', 56, 35),
    {
        name: 'deepak',
        age: 45,
        marks: 64
    },
    student2,
    student1
];
for (var _i = 0, students_1 = students; _i < students_1.length; _i++) {
    var student = students_1[_i];
    console.log(student);
}
