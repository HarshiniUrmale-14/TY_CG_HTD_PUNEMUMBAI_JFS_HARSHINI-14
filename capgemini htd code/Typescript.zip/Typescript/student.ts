class Student{

    constructor(
          public name: string,
          public age: number,
          public marks: number,
          public degree?: string
    ){}
    // printDetails(){
    //     console.log(`Name is ${this.name} age is ${this.age} and marks are ${this.marks}`);

   // }
}
let student1 = new Student('priya',99,99);  //object craetion-1
console.log(student1);
//student1.printDetails();

let student2:Student = {                  //object creation-2
    name: 'deepak',
    age: 45,
    marks: 64
}
console.log(student2);

let students: Student[] = [
    new Student('Subrat',56,35),
    {
        name: 'deepak',
        age: 45,
        marks: 64
    },
    student2,
    student1
];

for(let student of students){
    console.log(student);
}

class Graduate extends Student{
    constructor(
         name: string,
         age: number,
         marks: number,
        degree?: string
    ){
        super(name,age, marks)
    }
}
