var myName = 'mayu';
//myName = 123; gives error i.e. called static typing =>cannoot change the datatype
var company; //implicitly considered as any
company = 123;
company = 'abc';
company = true;
//-----------------------union data type---------------------------
var age;
age = 22;
age = 'twenty-two';
//age = true; => error -->only string and number can be stored 
//-------------------------tuple------------------------------------
var details = ['abc', 345, 321];
//array
var mobiles = ['iphone', 'samsung', '5050', 'true', 'false'];
var mobile = ['iphone', 'samsung', '5050', 'true', 'false'];
mobile = 345638;
//number
function add(a, b) {
    return a + b;
}
