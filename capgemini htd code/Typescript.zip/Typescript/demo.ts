let myName = 'mayu';
 //myName = 123; gives error i.e. called static typing =>cannoot change the datatype

let company;//implicitly considered as any
company=123;
company ='abc';
company = true;

//-----------------------union data type---------------------------

let age:string | number;
age = 22;
age ='twenty-two';
//age = true; => error -->only string and number can be stored 

//-------------------------tuple------------------------------------
let details : [string ,number ,number] = ['abc' , 345,321];

//array
let mobiles: string[] =['iphone','samsung','5050','true','false'];

let mobile: string[] | number=['iphone','samsung','5050','true','false'];
mobile = 345638;

//  number
function add(a:number , b:number):number{
    return a+b;
}