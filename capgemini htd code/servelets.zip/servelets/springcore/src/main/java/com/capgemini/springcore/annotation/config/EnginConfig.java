package com.capgemini.springcore.annotation.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import com.capgemini.springcore.annotations.bean.Isuzu;
import com.capgemini.springcore.annotations.bean.VW;
import com.capgemini.springcore.interfaces.Engine;

@Configuration
 class EnginConfig {
	@Bean(name="isuszu")
	@Primary
	public Engine getIsuzu() {
		return new Isuzu();
	}

	@Bean(name="vw")
	public Engine getVW() {
		return new VW();
	}
}
