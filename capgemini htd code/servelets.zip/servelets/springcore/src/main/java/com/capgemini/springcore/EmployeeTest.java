package com.capgemini.springcore;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.springcore.beans.EmployeeBean;

public class EmployeeTest {

	public static void main(String[] args) {
		//instantiate the container
		ApplicationContext context =new ClassPathXmlApplicationContext("beans.xml");
		EmployeeBean  employeeBean =(EmployeeBean)context.getBean("employee1");
		EmployeeBean  employeeBean1 =context.getBean("employee2",EmployeeBean.class);
		System.out.println("employee id :"+ employeeBean.getEmpid());
		System.out.println("employee name :"+ employeeBean.getEmpname());
		System.out.println("employee id :"+ employeeBean1.getEmpid());
		System.out.println("employee name :"+ employeeBean1.getEmpname());
		
	}

}