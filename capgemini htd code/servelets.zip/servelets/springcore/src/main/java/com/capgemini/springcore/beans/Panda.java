package com.capgemini.springcore.beans;

import com.capgemini.springcore.interfaces.Animal;

public class Panda implements Animal {

	@Override
	public void eat() {
System.out.println("panda eat");		
	}

	@Override
	public void speak() {
System.out.println("panda sleep");		
	}

	@Override
	public void walk() {
System.out.println("panda walk");		
	}

}
