package com.capgemini.springcore.annotations.bean;

import com.capgemini.springcore.interfaces.Animal;

public class Dog implements Animal {

	@Override
	public void eat() {
System.out.println("dog eat");		
	}

	@Override
	public void speak() {
System.out.println("dog sleep");		
	}

	@Override
	public void walk() {
System.out.println("dog walk");		
	}

}
