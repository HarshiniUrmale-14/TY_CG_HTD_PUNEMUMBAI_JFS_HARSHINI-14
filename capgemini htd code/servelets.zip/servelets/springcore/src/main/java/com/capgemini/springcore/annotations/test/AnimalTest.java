package com.capgemini.springcore.annotations.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

import com.capgemini.springcore.annotation.config.PetConfig;
import com.capgemini.springcore.annotations.bean.Pet;


public class AnimalTest {

	public static void main(String[] args) {
	ApplicationContext context = new AnnotationConfigApplicationContext(PetConfig.class);
	Pet pet = context.getBean(Pet.class);
	((AbstractApplicationContext)context).registerShutdownHook();
	
	System.out.println(pet.getName());
	pet.getAnimal().walk();
	pet.getAnimal().speak();
	pet.getAnimal().eat();

	}

}
