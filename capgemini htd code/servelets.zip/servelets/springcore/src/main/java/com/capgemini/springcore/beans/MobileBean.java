package com.capgemini.springcore.beans;

public class MobileBean {
	private String brandname;
	private String modelname;
	private int price;
	MobileDisplayBean mobiledisbean;
	
	public String getBrandname() {
		return brandname;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public void setBrandname(String brandname) {
		this.brandname = brandname;
	}
	public String getModelname() {
		return modelname;
	}
	public void setModelname(String modelname) {
		this.modelname = modelname;
	}
	public MobileDisplayBean getMobiledisbean() {
		return mobiledisbean;
	}
	public void setMobiledisbean(MobileDisplayBean mobiledisbean) {
		this.mobiledisbean = mobiledisbean;
	}
	
}
