package com.capgemini.springcore.annotations.test;



import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.springcore.annotations.bean.Car;


public class CarTest {

	public static void main(String[] args) {
		ApplicationContext context =new ClassPathXmlApplicationContext("carconfig.xml");
	Car myCar = context.getBean("myCar",Car.class);
		((AbstractApplicationContext)context).registerShutdownHook();
		System.out.println(myCar.getModelname());
		System.out.println(myCar.getModelno());
		System.out.println("engine details");
		System.out.println(myCar.getEngine().getCC());
		System.out.println(myCar.getEngine().getType());
		
	}

}
