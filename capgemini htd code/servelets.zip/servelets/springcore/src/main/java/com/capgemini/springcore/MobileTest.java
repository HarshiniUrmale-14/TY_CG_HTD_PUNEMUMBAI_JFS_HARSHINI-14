package com.capgemini.springcore;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.springcore.beans.MobileBean;

public class MobileTest {

	public static void main(String[] args) {
		ApplicationContext context =new ClassPathXmlApplicationContext("mobile.xml");
		MobileBean mobilebean=context.getBean("mobile", MobileBean.class);
		
		System.out.println( mobilebean.getBrandname());
		System.out.println( mobilebean.getModelname());
		System.out.println (mobilebean.getPrice());
		
		System.out.println( mobilebean.getMobiledisbean().getDisplaysize());
		System.out.println( mobilebean.getMobiledisbean().getResolution());
	}//main ended

}//class ended
