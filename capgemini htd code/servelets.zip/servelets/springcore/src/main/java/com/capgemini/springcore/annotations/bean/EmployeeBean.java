package com.capgemini.springcore.annotations.bean;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class EmployeeBean {
	private int empid;
	private String empname;
	@Autowired
	@Qualifier("test")
	private DepartmentBean deptbean;
	

	//getter and setters
	public DepartmentBean getDeptbean() {
		return deptbean;
	}

	public void setDeptbean(DepartmentBean deptbean) {
		this.deptbean = deptbean;
	}

	public int getEmpid() {
		return empid;
	}

	public void setEmpid(int empid) {
		this.empid = empid;
	}

	public String getEmpname() {
		return empname;
	}

	public void setEmpname(String empname) {
		this.empname = empname;
	}

	//lifecycle method
	
	@PostConstruct
	public void init() {
		System.out.println("initialization");

	}
	@PreDestroy
	public void destroy() {
		System.out.println("destroy");
	}

}
