package com.capgemini.springcore.beans;

public class MobileDisplayBean {
	private String displaysize;
	private  String resolution;
	public String getDisplaysize() {
		return displaysize;
	}
	public void setDisplaysize(String displaysize) {
		this.displaysize = displaysize;
	}
	public String getResolution() {
		return resolution;
	}
	public void setResolution(String resolution) {
		this.resolution = resolution;
	}
		
	

}
