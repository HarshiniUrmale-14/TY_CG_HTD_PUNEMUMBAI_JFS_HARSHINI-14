package com.capgemini.springcore;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.springcore.beans.EmployeeBean;

public class EmployeeTest2 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		ApplicationContext context = new ClassPathXmlApplicationContext("employeeConfig.xml");

		EmployeeBean emp1 = context.getBean("employee", EmployeeBean.class);
		System.out.println("enter emp id:");
		int empId = sc.nextInt();
		sc.nextLine();
		System.out.println("enter emp name:");
		String name = sc.nextLine();

		emp1.setEmpid(empId);
		emp1.setEmpname(name);

		EmployeeBean emp2 = context.getBean("employee", EmployeeBean.class);
		System.out.println("enter emp2 id:");
		int empId2 = sc.nextInt();
		sc.nextLine();
		System.out.println("enter emp2 name:");
		String name2 = sc.nextLine();

		emp2.setEmpid(empId2);
		emp2.setEmpname(name2);

		System.out.println("emp1 id = " + emp1.getEmpid());
		System.out.println("emp1 name = " + emp1.getEmpname());
		System.out.println("emp2 id =" + emp2.getEmpid());
		System.out.println("emp2 name =" + emp2.getEmpname());

	}

}
