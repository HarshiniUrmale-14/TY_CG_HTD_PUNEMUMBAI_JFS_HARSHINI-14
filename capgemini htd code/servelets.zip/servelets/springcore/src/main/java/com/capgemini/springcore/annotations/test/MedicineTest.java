package com.capgemini.springcore.annotations.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.springcore.beans.Medicine;

public class MedicineTest {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("MedicineConfig.xml");
		 Medicine medicine= context.getBean("medicine",Medicine.class);
		System.out.println(medicine.getName());
			System.out.println(medicine.getType());
			System.out.println(medicine.getPrice());
			//System.out.println(medicine.getDrugs());
			System.out.println(medicine.getDrugsSet());
			
	}

}
