package com.capgemini.springcore;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.springcore.beans.MessageBean;

public class MessageTest {

	public static void main(String[] args) {
		ApplicationContext context =new ClassPathXmlApplicationContext("beans.xml");
		//((AbstractApplicationContext)context).registerShutdownHook();
		
		MessageBean meassageBean=(MessageBean )context.getBean("messageBean");
		System.out.println(meassageBean.getMessage());
		
		((AbstractApplicationContext)context).close();
	}//end of main

}//end of class
