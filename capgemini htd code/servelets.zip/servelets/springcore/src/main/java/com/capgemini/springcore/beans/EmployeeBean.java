package com.capgemini.springcore.beans;

public class EmployeeBean {
	private int empid;
	private String empname;
	private DepartmentBean departmentbean;
	
	
	public EmployeeBean(int empid, String empname, DepartmentBean departmentbean) {
		super();
		this.empid = empid;
		this.empname = empname;
		this.departmentbean = departmentbean;
	}


	public int getEmpid() {
		return empid;
	}


	public void setEmpid(int empid) {
		this.empid = empid;
	}


	public String getEmpname() {
		return empname;
	}


	public void setEmpname(String empname) {
		this.empname = empname;
	}


	public DepartmentBean getDepartmentbean() {
		return departmentbean;
	}


	public void setDepartmentbean(DepartmentBean departmentbean) {
		this.departmentbean = departmentbean;
	}
	
}
