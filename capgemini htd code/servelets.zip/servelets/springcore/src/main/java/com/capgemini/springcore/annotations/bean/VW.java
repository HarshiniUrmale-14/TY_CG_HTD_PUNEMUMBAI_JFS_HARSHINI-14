package com.capgemini.springcore.annotations.bean;

import com.capgemini.springcore.interfaces.Engine;

public class VW implements Engine {

	@Override
	public int getCC() {
		return 16556;
	}

	@Override
	public String getType() {
		return "3-stroke petrol";
	}

}
