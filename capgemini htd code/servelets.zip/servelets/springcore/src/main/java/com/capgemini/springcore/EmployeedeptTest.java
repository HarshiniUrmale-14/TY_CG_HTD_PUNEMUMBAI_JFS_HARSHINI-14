package com.capgemini.springcore;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.springcore.beans.EmployeeBean;

public class EmployeedeptTest {

	public static void main(String[] args) {
		/*
		 * ApplicationContext context =new
		 * ClassPathXmlApplicationContext("employeeConfig.xml");
		 */
		ApplicationContext context =new ClassPathXmlApplicationContext("employeeconfig2.xml");
		EmployeeBean employeeBean=context.getBean("employee", EmployeeBean.class);
		System.out.println( employeeBean.getEmpid());
		System.out.println( employeeBean.getEmpname());
		System.out.println( employeeBean.getDepartmentbean().getDeptid());
		System.out.println( employeeBean.getDepartmentbean().getDeptname());
	}

}
