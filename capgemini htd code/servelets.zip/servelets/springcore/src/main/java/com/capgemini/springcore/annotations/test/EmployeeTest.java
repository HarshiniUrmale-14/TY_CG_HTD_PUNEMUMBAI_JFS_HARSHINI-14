package com.capgemini.springcore.annotations.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

import com.capgemini.springcore.annotation.config.EmployeeConfig;
import com.capgemini.springcore.annotations.bean.EmployeeBean;

public class EmployeeTest {

	public static void main(String[] args) {
		ApplicationContext context = new AnnotationConfigApplicationContext(EmployeeConfig.class);
		EmployeeBean employeeBean = context.getBean(EmployeeBean.class);
		((AbstractApplicationContext)context).registerShutdownHook();
		
		System.out.println(employeeBean.getEmpid());
		System.out.println(employeeBean.getEmpname());
		System.out.println("department info");
		System.out.println(employeeBean.getDeptbean().getDeptid());
		System.out.println(employeeBean.getDeptbean().getDeptname());
		
		
		
		 //((AbstractApplicationContext)context).close();
		 
	}

}
