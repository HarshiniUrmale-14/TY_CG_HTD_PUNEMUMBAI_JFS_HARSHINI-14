package com.capgemini.springcore.annotation.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.capgemini.springcore.annotations.bean.DepartmentBean;

@Configuration
public class DepartmentConfig {

	@Bean(name = "dev")
	//@Primary
	public DepartmentBean getDevlopmentdept() {
		DepartmentBean departmentBean = new DepartmentBean();

		departmentBean.setDeptid(113);
		departmentBean.setDeptname("development");
		return departmentBean;
	}

	@Bean(name = "test")
	public DepartmentBean getTesting() {
		DepartmentBean departmentBean = new DepartmentBean();

		departmentBean.setDeptid(145);
		departmentBean.setDeptname("testing");
		return departmentBean;
	}

	@Bean(name = "hr")
	public DepartmentBean getHr() {
		DepartmentBean departmentBean = new DepartmentBean();

		departmentBean.setDeptid(136);
		departmentBean.setDeptname("hr");
		return departmentBean;
	}
}
