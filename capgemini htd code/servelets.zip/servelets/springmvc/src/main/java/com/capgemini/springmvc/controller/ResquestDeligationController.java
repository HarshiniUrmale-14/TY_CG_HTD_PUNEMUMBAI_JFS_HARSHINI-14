package com.capgemini.springmvc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class ResquestDeligationController {
	@GetMapping("/redirect")
	public String redirectRequest() {
		return "redirect:http://www.google.com";
	}
	
	@GetMapping("/forward")
	public String forward() {
		return "forward:/loginform";
	}

//we always include in jsp and only use  include in jsp dont use forward in jsp
	/*
	 * @GetMapping("/include") public String include() { return
	 * "include:/loginform"; }
	 */

}