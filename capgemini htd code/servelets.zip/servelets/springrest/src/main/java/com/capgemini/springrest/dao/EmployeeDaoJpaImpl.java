package com.capgemini.springrest.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceUnit;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.capgemini.springrest.beans.EmployeeInfoBean;



@Repository//connect with the data 
public class EmployeeDaoJpaImpl implements EmployeeDao {
	@PersistenceUnit
	EntityManagerFactory emf ;

	@Override
	public EmployeeInfoBean getEmployee(int empId) {
		EntityManager manager = emf.createEntityManager();
		EmployeeInfoBean employeeInfoBean = manager.find(EmployeeInfoBean.class, empId);
		manager.close();

		return employeeInfoBean;
	}

	@Override
	public EmployeeInfoBean authenticate(int empId, String password) {
		EntityManager manager = emf.createEntityManager();
		String jpql = "from EmployeeInfoBean where empId=:empId and password=:password";
		Query query = manager.createQuery(jpql);
		query.setParameter("empId", empId);
		query.setParameter("password", password);
		EmployeeInfoBean employeeInfoBean = null;
		try {
			employeeInfoBean = (EmployeeInfoBean) query.getSingleResult();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return employeeInfoBean;
	}

	@Override
	public boolean addEmployee(EmployeeInfoBean employeeInfoBean) {
		EntityManager manager = emf.createEntityManager();
		boolean isAdded = false;
		try {
			EntityTransaction tx = manager.getTransaction();
			tx.begin();
			manager.persist(employeeInfoBean);
			tx.commit();
			isAdded = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		manager.close();

		return isAdded;
	}

	@Override
	public boolean updateEmployee(EmployeeInfoBean employeeInfoBean) {
		EntityManager manager = emf.createEntityManager();
		EmployeeInfoBean infoBean = manager.find(EmployeeInfoBean.class, employeeInfoBean.getEmpId());
		boolean isupdated = false;
		if (infoBean != null) {
			String name = employeeInfoBean.getEmpname();
			if (name != null) {
				infoBean.setEmpname(name);

			}
			int age = employeeInfoBean.getAge();
			if (age > 18) {
				infoBean.setAge(age);
			}
			double salary=employeeInfoBean.getSalary();
			if(salary>0) {
				infoBean.setSalary(salary);
			}
		long mobile=employeeInfoBean.getMobile();
			if(salary>0) {
				infoBean.setMobile(mobile);
			}
			String designation=employeeInfoBean.getDesignation();
			if(salary>0) {
				infoBean.setDesignation(designation);
			}
			char gender =employeeInfoBean.getGender();
			if(salary>0) {
				infoBean.setGender(gender);
			}
		String pwd=employeeInfoBean.getPassword();
			if(salary>0) {
				infoBean.setPassword(pwd);
			}
			try {
				EntityTransaction tx = manager.getTransaction();
				tx.begin();
				manager.persist(infoBean);
				tx.commit();
				isupdated = true;
			} catch (Exception e) {
				e.printStackTrace();
			}
			manager.close();
		}

	return isupdated;
	}
	@Override
	public boolean deleteEmployee(int empId) {
		
		EntityManager entityManager = emf.createEntityManager();
		boolean isDeleted = false;

		try {
			EntityTransaction tx = entityManager.getTransaction();
			tx.begin();
			EmployeeInfoBean employeeInfoBean= entityManager.find(EmployeeInfoBean.class, empId);
			entityManager.remove(employeeInfoBean);
			tx.commit();
			isDeleted = true;
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		entityManager.close();
		return isDeleted;
	}// End of deleteEmployee()

	@Override
	public List<EmployeeInfoBean> getAllEmployees() {
		EntityManager manager = emf.createEntityManager();
		String jpql = "from EmployeeInfoBean";
		Query query = manager.createQuery(jpql);
		
		List<EmployeeInfoBean> employeesList = null;
		try {
			employeesList = query.getResultList();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return employeesList;
		
	}// End of getAllEmployees()

	

}
