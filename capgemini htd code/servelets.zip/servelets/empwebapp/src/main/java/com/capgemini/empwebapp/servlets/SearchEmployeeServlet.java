package com.capgemini.empwebapp.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.empwebapp.beans.EmployeeInfoBean;
import com.capgemini.empwebapp.dao.EmployeeDao;
import com.capgemini.empwebapp.dao.EmployeeDaoJpaImpl;

@WebServlet("/searchEmployee")
public class SearchEmployeeServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String empIdVal = req.getParameter("empId");
		int empId = Integer.parseInt(empIdVal);

		EmployeeDao dao = new EmployeeDaoJpaImpl();
		EmployeeInfoBean employeeInfoBean = dao.getEmployee(empId);

		PrintWriter out = resp.getWriter();
		out.println("<html>");
		out.println("<body>");

		if (employeeInfoBean != null) {
			out.println("<h2>employeeid" + empId + "found</h2>");
			out.println("employee name" + employeeInfoBean.getEmpname());
			out.println("<br>age" + employeeInfoBean.getAge());
			out.println("<br>mobile" + employeeInfoBean.getMobile());
			out.println("<br>gender" + employeeInfoBean.getGender());
			out.println("<br>salary" + employeeInfoBean.getSalary());
			out.println("<br>designation" + employeeInfoBean.getDesignation());
			out.println("<br>password" + employeeInfoBean.getPassword());
		} else {
			out.println("<h3>page not found</h3>");
		}

	}
}
