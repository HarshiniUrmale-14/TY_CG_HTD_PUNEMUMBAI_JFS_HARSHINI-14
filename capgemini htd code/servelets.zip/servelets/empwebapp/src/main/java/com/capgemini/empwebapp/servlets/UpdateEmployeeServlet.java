package com.capgemini.empwebapp.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capgemini.empwebapp.beans.EmployeeInfoBean;
import com.capgemini.empwebapp.dao.EmployeeDao;
import com.capgemini.empwebapp.dao.EmployeeDaoJpaImpl;

@WebServlet("/updateEmployee")
public class UpdateEmployeeServlet extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		HttpSession session = req.getSession(false);
		if (session != null) {
			int empId = Integer.parseInt(req.getParameter("empId"));
			String empname = req.getParameter("empname");
			String password = req.getParameter("password");
			String designation = req.getParameter("designation");
			String mobile = req.getParameter("mobile");
			String age = req.getParameter("age");
			String salary = req.getParameter("salary");
			String gender = req.getParameter("gender");
			
			

			EmployeeInfoBean employeeInfoBean = new EmployeeInfoBean();
			employeeInfoBean.setEmpId(empId);
			if(empname!=null && !empname.isEmpty()) {
				employeeInfoBean.setEmpname(empname);
				
			}
			if(salary!=null && !salary.isEmpty()) {
				employeeInfoBean.setSalary(Double.parseDouble(salary));
				
			}
			if(age!=null && !age.isEmpty()) {
				employeeInfoBean.setAge(Integer.parseInt(age));
				
			}
			if(mobile!=null &&  !mobile.isEmpty()) {
				employeeInfoBean.setMobile(Long.parseLong(mobile));
				 
				
			}
			if(gender!=null  && !gender.isEmpty()) {
				employeeInfoBean.setGender(gender.charAt(0));
				
			}
			if(designation!=null && !designation.isEmpty()) {
				employeeInfoBean.setDesignation(designation);
				
			}
			if(password!=null && !password.isEmpty()) {
				employeeInfoBean.setPassword(password);
				
			}
			EmployeeDao dao = new EmployeeDaoJpaImpl();
			boolean isupdated = dao.updateEmployee(employeeInfoBean);
			
			PrintWriter out = resp.getWriter();
			out.println("<html>");
			out.println("<body>");
			if (isupdated) {

				out.println("<h2>employee record has sucessfully updated </h2>");
			} else {
				out.println("<h2 style='color:red'> unable to add employee</h2>");
			}
			out.println("<html>");
			out.println("<body>");
			
			RequestDispatcher dispatcher = req.getRequestDispatcher("./updateemployee.html");
			dispatcher.include(req, resp);
		} else {
			PrintWriter out = resp.getWriter();

			out.println("<html>");
			out.println("<body>");
			out.println("<h2 style='color:red'> PLEASE LOGIN FIRST</h2>");
			out.println("</body>");
			out.println("</html>");

			RequestDispatcher dispatcher = req.getRequestDispatcher("./loginform.html");
			dispatcher.include(req, resp);

		}

	}
}
