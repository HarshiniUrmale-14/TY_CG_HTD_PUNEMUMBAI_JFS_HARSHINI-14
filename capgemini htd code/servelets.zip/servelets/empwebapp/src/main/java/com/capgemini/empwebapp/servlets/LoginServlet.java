package com.capgemini.empwebapp.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capgemini.empwebapp.beans.EmployeeInfoBean;
import com.capgemini.empwebapp.dao.EmployeeDao;
import com.capgemini.empwebapp.dao.EmployeeDaoJpaImpl;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //get  the  form data
		int empIdVal = Integer.parseInt(req.getParameter("empId"));
		String passwordVal = req.getParameter("password");
		
		EmployeeDao dao = new EmployeeDaoJpaImpl();
	    EmployeeInfoBean  employeeInfoBean = dao.authenticate(empIdVal, passwordVal);
		
		PrintWriter out=resp.getWriter();
		out.println("<html>");
		out.println("<body>");
		
		RequestDispatcher dispatcher = null;
		if (employeeInfoBean!=null) {
			//valid credentials
			HttpSession session = req.getSession(true);
			session.setMaxInactiveInterval(7 * 60 * 24 * 60);
			session.setAttribute("empInfo", employeeInfoBean);
			
			out.println("<h2>hello   "+  employeeInfoBean.getEmpname()+"</h2>");
			dispatcher = req.getRequestDispatcher("./homepage.html");
		} else {
			//invalid credentails
			out.println("<h2 style='color:red'>invalid credential</h2>");
			dispatcher = req.getRequestDispatcher("./loginform.html");
			
		}
		dispatcher.include(req, resp);
		
		out.println("</body>");
		out.println("</html>");
	}

}
