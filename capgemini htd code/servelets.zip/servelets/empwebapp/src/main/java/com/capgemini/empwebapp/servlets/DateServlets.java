package com.capgemini.empwebapp.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class DateServlets extends HttpServlet {

	// instatiation of servlet
	public DateServlets() {
		System.out.println("its instansiation phase");
	}
//initialisation
	public void init() throws ServletException {
		System.out.println("initialization phase");
	}
//providing service using doget method
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		System.out.println("its service phase");
		Date date = new Date();

		ServletContext context = getServletContext();
		String companyNameVal = context.getInitParameter("companyName");

		// resp.setHeader("refresh","1");
		resp.setContentType("text/html");

		PrintWriter out = resp.getWriter();
		out.println("<html>");
		out.println("<body>");
		out.println("<h1>current system date  and time-<br>");
		out.println(date + "</h1>");
		out.println("<h1> context parama :" + companyNameVal + "</h1>");
		out.println("</body>");
		out.println("<html>");
	}// end of doGet()
//destroy the service3
	@Override
	public void destroy() {
		super.destroy();
		System.out.println("servlet destroy");
	}
}// end of class
