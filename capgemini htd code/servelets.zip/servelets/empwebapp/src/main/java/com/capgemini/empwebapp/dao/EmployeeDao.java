package com.capgemini.empwebapp.dao;

import com.capgemini.empwebapp.beans.EmployeeInfoBean;

public interface EmployeeDao {
	public EmployeeInfoBean getEmployee(int empId);
	public  EmployeeInfoBean authenticate(int empId, String password);
	public boolean addEmployee(EmployeeInfoBean employeeInfoBean);
	public boolean updateEmployee(EmployeeInfoBean employeeInfoBean);
//public boolean deleteEmployee(EmployeeInfoBean employeeInfoBean);
}
