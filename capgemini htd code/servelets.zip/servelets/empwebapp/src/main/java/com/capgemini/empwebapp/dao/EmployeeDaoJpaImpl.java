package com.capgemini.empwebapp.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.capgemini.empwebapp.beans.EmployeeInfoBean;

public class EmployeeDaoJpaImpl implements EmployeeDao {
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("employeePersistentUnit");

	@Override
	public EmployeeInfoBean getEmployee(int empId) {
		EntityManager manager = emf.createEntityManager();
		EmployeeInfoBean employeeInfoBean = manager.find(EmployeeInfoBean.class, empId);
		manager.close();

		return employeeInfoBean;
	}

	@Override
	public EmployeeInfoBean authenticate(int empId, String password) {
		EntityManager manager = emf.createEntityManager();
		String jpql = "from EmployeeInfoBean where empId=:empId and password=:password";
		Query query = manager.createQuery(jpql);
		query.setParameter("empId", empId);
		query.setParameter("password", password);
		EmployeeInfoBean employeeInfoBean = null;
		try {
			employeeInfoBean = (EmployeeInfoBean) query.getSingleResult();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return employeeInfoBean;
	}

	@Override
	public boolean addEmployee(EmployeeInfoBean employeeInfoBean) {
		EntityManager manager = emf.createEntityManager();
		boolean isAdded = false;
		try {
			EntityTransaction tx = manager.getTransaction();
			tx.begin();
			manager.persist(employeeInfoBean);
			tx.commit();
			isAdded = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		manager.close();

		return isAdded;
	}

	@Override
	public boolean updateEmployee(EmployeeInfoBean employeeInfoBean) {
		EntityManager manager = emf.createEntityManager();
		EmployeeInfoBean infoBean = manager.find(EmployeeInfoBean.class, employeeInfoBean.getEmpId());
		boolean isupdated = false;
		if (infoBean != null) {
			String name = employeeInfoBean.getEmpname();
			if (name != null) {
				infoBean.setEmpname(name);

			}
			int age = employeeInfoBean.getAge();
			if (age > 18) {
				infoBean.setAge(age);
			}
			double salary=employeeInfoBean.getSalary();
			if(salary>0) {
				infoBean.setSalary(salary);
			}
		long mobile=employeeInfoBean.getMobile();
			if(salary>0) {
				infoBean.setMobile(mobile);
			}
			String designation=employeeInfoBean.getDesignation();
			if(salary>0) {
				infoBean.setDesignation(designation);
			}
			char gender =employeeInfoBean.getGender();
			if(salary>0) {
				infoBean.setGender(gender);
			}
		String pwd=employeeInfoBean.getPassword();
			if(salary>0) {
				infoBean.setPassword(pwd);
			}
			try {
				EntityTransaction tx = manager.getTransaction();
				tx.begin();
				manager.persist(employeeInfoBean);
				tx.commit();
				isupdated = true;
			} catch (Exception e) {
				e.printStackTrace();
			}
			manager.close();
		}

	return isupdated;
	}
}
